import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dc-business-solutions-integration-icons',
  templateUrl: './business-solutions-integration-icons.component.html',
  styleUrls: ['./business-solutions-integration-icons.component.scss']
})
export class BusinessSolutionsIntegrationIconsComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
