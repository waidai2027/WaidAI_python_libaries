import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dc-business-solutions-get-theme',
  templateUrl: './business-solutions-get-theme.component.html',
  styleUrls: ['./business-solutions-get-theme.component.scss']
})
export class BusinessSolutionsGetThemeComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
