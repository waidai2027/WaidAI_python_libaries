import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dc-business-solutions-heading',
  templateUrl: './business-solutions-heading.component.html',
  styleUrls: ['./business-solutions-heading.component.scss']
})
export class BusinessSolutionsHeadingComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
