import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dc-business-solutions',
  templateUrl: './business-solutions.component.html',
  styleUrls: ['./business-solutions.component.scss']
})
export class BusinessSolutionsComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
