import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dc-automate-social',
  templateUrl: './automate-social.component.html',
  styleUrls: ['./automate-social.component.scss']
})
export class AutomateSocialComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
