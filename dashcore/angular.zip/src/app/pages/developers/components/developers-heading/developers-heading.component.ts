import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dc-developers-heading',
  templateUrl: './developers-heading.component.html',
  styleUrls: ['./developers-heading.component.scss']
})
export class DevelopersHeadingComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
