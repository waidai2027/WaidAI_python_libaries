import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dc-app-landing-download',
  templateUrl: './app-landing-download.component.html',
  styleUrls: ['./app-landing-download.component.scss']
})
export class AppLandingDownloadComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
