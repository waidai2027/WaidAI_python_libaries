import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dc-app-landing',
  templateUrl: './app-landing.component.html',
  styleUrls: ['./app-landing.component.scss']
})
export class AppLandingComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
