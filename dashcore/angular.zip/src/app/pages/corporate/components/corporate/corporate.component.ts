import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dc-corporate',
  templateUrl: './corporate.component.html',
  styleUrls: ['./corporate.component.scss']
})
export class CorporateComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
