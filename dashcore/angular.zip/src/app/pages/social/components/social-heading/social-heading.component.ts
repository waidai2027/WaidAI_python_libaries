import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dc-social-heading',
  templateUrl: './social-heading.component.html',
  styleUrls: ['./social-heading.component.scss']
})
export class SocialHeadingComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
