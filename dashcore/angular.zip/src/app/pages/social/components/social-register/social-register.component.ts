import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dc-social-register',
  templateUrl: './social-register.component.html',
  styleUrls: ['./social-register.component.scss']
})
export class SocialRegisterComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
