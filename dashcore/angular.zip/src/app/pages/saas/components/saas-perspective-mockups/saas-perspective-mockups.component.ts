import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dc-saas-perspective-mockups',
  templateUrl: './saas-perspective-mockups.component.html',
  styleUrls: ['./saas-perspective-mockups.component.scss']
})
export class SaasPerspectiveMockupsComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
