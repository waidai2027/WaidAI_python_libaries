import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dc-app-landing2-download',
  templateUrl: './app-landing2-download.component.html',
  styleUrls: ['./app-landing2-download.component.scss']
})
export class AppLanding2DownloadComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
