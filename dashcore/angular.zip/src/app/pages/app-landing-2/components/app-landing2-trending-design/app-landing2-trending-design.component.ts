import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dc-app-landing2-trending-design',
  templateUrl: './app-landing2-trending-design.component.html',
  styleUrls: ['./app-landing2-trending-design.component.scss']
})
export class AppLanding2TrendingDesignComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
