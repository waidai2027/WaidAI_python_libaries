import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dc-app-landing2-focus-on-success',
  templateUrl: './app-landing2-focus-on-success.component.html',
  styleUrls: ['./app-landing2-focus-on-success.component.scss']
})
export class AppLanding2FocusOnSuccessComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
