import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dc-app-landing2',
  templateUrl: './app-landing2.component.html',
  styleUrls: ['./app-landing2.component.scss']
})
export class AppLanding2Component implements OnInit {
  constructor() {}

  ngOnInit() {}
}
