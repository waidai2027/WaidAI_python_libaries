import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dc-faqs-questions',
  templateUrl: './faqs-questions.component.html',
  styleUrls: ['./faqs-questions.component.scss']
})
export class FaqsQuestionsComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
