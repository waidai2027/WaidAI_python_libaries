import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dc-smart-business',
  templateUrl: './smart-business.component.html',
  styleUrls: ['./smart-business.component.scss']
})
export class SmartBusinessComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
