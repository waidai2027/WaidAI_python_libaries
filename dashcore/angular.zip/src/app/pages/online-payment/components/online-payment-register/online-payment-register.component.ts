import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dc-online-payment-register',
  templateUrl: './online-payment-register.component.html',
  styleUrls: ['./online-payment-register.component.scss']
})
export class OnlinePaymentRegisterComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
