import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dc-online-payment',
  templateUrl: './online-payment.component.html',
  styleUrls: ['./online-payment.component.scss']
})
export class OnlinePaymentComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
