import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dc-integration',
  templateUrl: './integration.component.html',
  styleUrls: ['./integration.component.scss']
})
export class IntegrationComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
