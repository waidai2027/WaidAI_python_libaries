import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dc-integration-heading',
  templateUrl: './integration-heading.component.html',
  styleUrls: ['./integration-heading.component.scss']
})
export class IntegrationHeadingComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
