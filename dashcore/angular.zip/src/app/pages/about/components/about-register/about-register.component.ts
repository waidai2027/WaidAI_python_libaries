import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dc-about-register',
  templateUrl: './about-register.component.html',
  styleUrls: ['./about-register.component.scss']
})
export class AboutRegisterComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
