import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dc-about-video',
  templateUrl: './about-video.component.html',
  styleUrls: ['./about-video.component.scss']
})
export class AboutVideoComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
