import { NgModule } from '@angular/core';
import { CountersModule } from './counters/counters.module';

@NgModule({
  declarations: [],
  imports: [CountersModule]
})
export class BlocksModule {}
