<?php sleep(1); ?>
<?php include "forms/{$_GET['step_number']}.php" ?>
