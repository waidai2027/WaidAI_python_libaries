/**
 * Demo file. Add fuctionality to demo page
 */
import "simplebar";
import "simplebar/dist/simplebar.css";
