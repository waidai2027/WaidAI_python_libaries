/**
 * We use https://prismjs.com/ along with babel-plugin-prismjs for highlighting code.
 * If you want to change Prismjs configuration please update .babelrc file according to your needs
 **/
import Prism from "prismjs";

Prism.highlightAll();
